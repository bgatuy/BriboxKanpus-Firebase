(function () {
  const STORAGE_KEY = "monthlyReports";              // kunci TUNGGAL
  const LEGACY_KEY  = "monthlyData";                 // dibersihkan saat reset / migrasi

  // ===== UID helper (per-akun)
  function getUidOrAnon() {
    try {
      return (window.DriveSync?.getUser?.()?.uid)
          || (window.Auth?.getUid?.())
          || (window.Auth?.user?.uid)
          || (window.Auth?.currentUser?.()?.uid)
          || 'anon';
    } catch { return 'anon'; }
  }
  function monthlyCloudFile() { return `.monthly_data__${getUidOrAnon()}.json`; }

  /* ========== USER-SCOPE (per akun) ========== */
  const LS = {
    getItem(k){ return (window.AccountNS?.getItem?.(k)) ?? localStorage.getItem(k); },
    setItem(k,v){ if (window.AccountNS?.setItem) window.AccountNS.setItem(k, v); else localStorage.setItem(k, v); },
    removeItem(k){ try { if (window.AccountNS?.setItem) window.AccountNS.setItem(k, null); localStorage.removeItem(k);} catch{} },
    readJSON(k, def=[]){ try { return JSON.parse(this.getItem(k) || ''); } catch { return def; } },
    writeJSON(k, obj){ this.setItem(k, JSON.stringify(obj ?? [])); }
  };

  /* ========= SIDEBAR ========= */
  const sidebar   = document.querySelector('.sidebar');
  const overlay   = document.getElementById('sidebarOverlay') || document.querySelector('.sidebar-overlay');
  const sidebarLinks = document.querySelectorAll('.sidebar a');

  function openSidebar() { sidebar.classList.add('visible'); overlay?.classList.add('show'); document.body.style.overflow = 'hidden'; }
  function closeSidebar() { sidebar.classList.remove('visible'); overlay?.classList.remove('show'); document.body.style.overflow = ''; }
  function toggleSidebar() { sidebar.classList.contains('visible') ? closeSidebar() : openSidebar(); }
  window.toggleSidebar = toggleSidebar;

  overlay?.addEventListener('click', closeSidebar);
  document.addEventListener('click', (e) => {
    const isMobile = window.matchMedia('(max-width: 768px)').matches;
    if (!isMobile) return;
    const clickInsideSidebar = sidebar?.contains(e.target);
    const clickOnToggle = e.target.closest?.('.sidebar-toggle-btn');
    if (sidebar?.classList.contains('visible') && !clickInsideSidebar && !clickOnToggle) closeSidebar();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && sidebar?.classList.contains('visible')) closeSidebar(); });
  sidebarLinks.forEach(a => a.addEventListener('click', closeSidebar));

  document.addEventListener('DOMContentLoaded', function () {
    const title = document.querySelector('.dashboard-header h1')?.textContent?.toLowerCase() || "";
    const body = document.body;
    if (title.includes('trackmate'))      body.setAttribute('data-page', 'trackmate');
    else if (title.includes('appsheet'))  body.setAttribute('data-page', 'appsheet');
    else if (title.includes('serah'))     body.setAttribute('data-page', 'serah');
    else if (title.includes('merge'))     body.setAttribute('data-page', 'merge');
  });

  // ===== utils
  const $ = (id) => document.getElementById(id);
  const pad = (n) => String(n).padStart(2, "0");
  const norm = (s) => String(s || "").toLowerCase().normalize("NFKD").replace(/\s+/g, " ").trim();

  function loadReports() { return LS.readJSON(STORAGE_KEY, []); }
  function saveReports(arr) { LS.writeJSON(STORAGE_KEY, arr || []); }
  function showToast(msg) {
    const t = $("toast"); if(!t) return;
    t.textContent = msg; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"), 1600);
  }

  // ===== Migrasi sekali: gabungkan legacy -> STORAGE_KEY, lalu hapus legacy
  function migrateOnce(){
    try {
      const a = LS.readJSON(STORAGE_KEY, []);
      const b = LS.readJSON(LEGACY_KEY,  []);
      if (!b.length) return; // tidak ada legacy
      const map = new Map();
      const normRec = (x) => ({ id: x.id || [x.month,x.date,x.teknisi,x.createdAt].filter(Boolean).join('|'), ...x });
      [...a, ...b].forEach(r=>{
        const n = normRec(r); const ex = map.get(n.id);
        if (!ex) map.set(n.id,n);
        else {
          const tNew = new Date(n.updatedAt || n.createdAt || 0).getTime();
          const tOld = new Date(ex.updatedAt || ex.createdAt || 0).getTime();
          if (tNew >= tOld) map.set(n.id, n);
        }
      });
      LS.writeJSON(STORAGE_KEY, Array.from(map.values()));
      // bersihkan legacy agar tak kebaca lagi
      LS.removeItem(LEGACY_KEY);
    } catch {}
  }
  migrateOnce();

  // ===== Cloud mirror adapters
  async function monthlyGetLocal(){ return LS.readJSON(STORAGE_KEY, []); }
  async function monthlySetLocal(arr){ LS.writeJSON(STORAGE_KEY, arr || []); }

  // Debounced push ke Drive
  let _pushTimer = null;
  async function pushMirrorSilent(){
    if (_pushTimer) clearTimeout(_pushTimer);
    _pushTimer = setTimeout(async () => {
      try{
        const ok = await (window.DriveSync?.tryResume?.() || Promise.resolve(false));
        if (!ok && !window.DriveSync?.isLogged?.()) return;
        const data = await monthlyGetLocal();
        await window.DriveSync?.putJson?.(monthlyCloudFile(), { data });
      } catch {}
    }, 700);
  }

  // ===== pick month (URL -> latest in storage -> now)
  function pickActiveMonth() {
    const fromUrl = new URL(location.href).searchParams.get("month");
    if (fromUrl) return fromUrl;
    const all = loadReports();
    if (all.length) {
      const months = [...new Set(all.map(r=>r.month).filter(Boolean))];
      months.sort((a,b)=>b.localeCompare(a)); // desc YYYY-MM
      if (months[0]) return months[0];
    }
    const d = new Date();
    const pad = n => String(n).padStart(2,'0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}`;}

  const month = pickActiveMonth();

  // ===== elem refs
  const qInput = $("q");
  const tbody = $("tbody");
  const empty = $("empty");
  const badgeMonth = $("badgeMonth");

  // badge bulan
  (function setBadge(){
    const [yy,mm] = String(month).split("-").map(Number);
    let label = month || "—";
    if (!isNaN(yy) && !isNaN(mm)) label = new Date(yy,(mm||1)-1,1).toLocaleDateString("id-ID",{month:"long",year:"numeric"});
    if (badgeMonth) badgeMonth.textContent = label;
  })();

  // ===== filtering + render
  function applyFilters(){
    const q = norm(qInput?.value || "");
    let rows = loadReports().filter(r=>r.month===month);

    if(q){
      rows = rows.filter(r=>{
        const hay = [
          r.tanggalLabel,r.date,r.teknisi,r.lokasiDari,r.lokasiKe,r.jenis,r.detail,r.status,
          r.keterangan,r.jamMasuk,r.jamBerangkat,r.jamTiba,r.jamMulai,r.jamSelesai,
          r.durasiPenyelesaianStr,r.waktuTempuhStr,
          String(r.jarakKm ?? r.jarak ?? '')
        ].map(norm).join(" ");
        return hay.includes(q);
      });
    }
    rows.sort((a,b)=>{ const ad=a.date||"", bd=b.date||""; if(ad!==bd) return ad.localeCompare(bd); return (a.createdAt||"").localeCompare(b.createdAt||""); });

    renderTable(rows);
    if (empty) empty.style.display = rows.length ? "none" : "block";
    if (typeof tblCap !== 'undefined' && tblCap) tblCap.textContent = `${rows.length} entri ditampilkan`;
  }
  window.applyFilters = applyFilters;

  const esc = (s)=> String(s).replace(/[&<>"']/g, m => (
  { "&":"&amp;", "<":"&lt;", ">":"&gt;", "\"":"&quot;", "'":"&#39;" }[m]
));
  const fmtJam = (v) => {
    if (v == null || v === "") return "";
    const m = String(v).match(/^(\d{1,2}):(\d{2})$/);
    if (!m) return String(v);
    return `${parseInt(m[1], 10)}:${m[2]}`; // 07:05 -> 7:05
  };

  function renderTable(rows){
    if(!tbody) return;
    tbody.innerHTML = rows.map(r=>{
      const jarakVal = (r.jarakKm != null ? r.jarakKm : r.jarak);
      return `
      <tr data-id="${esc(r.id)}">
        <td>${esc(r.tanggalLabel||r.date||"-")}</td>
        <td class="col-teknisi">${esc(r.teknisi||"-")}</td>
        <td>${esc(r.lokasiDari||"-")}</td>
        <td>${esc(r.lokasiKe||"-")}</td>
        <td>${esc(r.jenis||"-")}</td>
        <td>${esc(r.detail||"-")}</td>
        <td>${esc(r.status||"-")}</td>
        <td>${esc(fmtJam(r.jamMasuk))}</td>
        <td>${esc(fmtJam(r.jamBerangkat))}</td>
        <td>${esc(fmtJam(r.jamTiba))}</td>
        <td>${esc(fmtJam(r.jamMulai))}</td>
        <td>${esc(fmtJam(r.jamSelesai))}</td>
        <td>${esc(r.durasiPenyelesaianStr||"0:00")}</td>
        <td class="num">${jarakVal==null || jarakVal==="" ? "" : jarakVal}</td>
        <td>${esc(r.waktuTempuhStr||"0:00")}</td>
        <td>${esc(r.keterangan||"")}</td>
        <td><button class="btn-del" data-id="${esc(r.id)}">Hapus</button></td>
      </tr>`;
    }).join("");

    // Hapus baris
    tbody.querySelectorAll(".btn-del").forEach(btn=>{
      btn.addEventListener("click", async ()=>{
        const id = btn.getAttribute("data-id");
        if(!id) return;
        if(!confirm("Hapus entri ini?")) return;
        const kept = loadReports().filter(x=>(x.id||"")!==id);
        saveReports(kept);
        showToast("Entri dihapus.");
        applyFilters();
        await pushMirrorSilent(); // mirror Drive
      });
    });
  }

  /* =======================
     ExcelJS AUTO-FIT HELPER
     ======================= */
  function autoFitColumns(ws, { min=8, max=48, padding=2, wrapCols=[5,6,16] } = {}) {
    const colCount = ws.columnCount || ws.actualColumnCount || 16;
    const readText = (cell) => {
      const v = cell?.value;
      if (v == null) return '';
      if (typeof v === 'string') return v;
      if (typeof v === 'number') return String(v);
      if (v && typeof v === 'object') {
        if (v.text) return String(v.text);
        if (Array.isArray(v.richText)) return v.richText.map(r => r.text || '').join('');
        if (v.result != null) return String(v.result);
        if (v.formula) return String(v.formula);
        if (v.date) return String(v.date);
      }
      return String(v);
    };

    for (let c = 1; c <= colCount; c++) {
      let maxLen = 0;

      [3,4].forEach(rn => {
        const t = readText(ws.getRow(rn).getCell(c)) || '';
        maxLen = Math.max(maxLen, ...t.split('\n').map(s => s.length));
      });

      ws.eachRow({ includeEmpty: false }, (row) => {
        if (row.number < 5) return;
        const t = readText(row.getCell(c)) || '';
        maxLen = Math.max(maxLen, ...t.split('\n').map(s => s.length));
      });

      const width = Math.min(Math.max(Math.ceil(maxLen + padding), min), max);
      ws.getColumn(c).width = width;
    }
  }

  /* ============== Helpers FULL CALENDAR untuk EXPORT ============== */
  const HARI_ID = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
  const BULAN_ID = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  const daysInMonth = (y, m) => new Date(y, m, 0).getDate(); // m=1..12
  const pad2 = (n)=> String(n).padStart(2,'0');
  const keyDate = (y,m,d)=> `${y}-${pad2(m)}-${pad2(d)}`;
  function tanggalLabel(y,m,d){ const dt=new Date(y,m-1,d); return `${HARI_ID[dt.getDay()]}, ${pad2(d)} ${BULAN_ID[m-1]} ${y}`; }
  const hmToExcelTime = (hm)=> {
    if(!hm) return null;
    const m = String(hm).match(/^(\d{1,2}):(\d{2})$/);
    if(!m) return null;
    return (+m[1]*60 + +m[2]) / (24*60);
  };

  function groupReportsByDate(reports){
    const map = new Map();
    for(const r of reports){
      let k = r.date;
      if(!k && r.tanggalLabel){
        const parts = String(r.tanggalLabel).split(' ');
        const d = parseInt(parts[1],10);
        const y = parseInt(parts[3],10);
        const m = BULAN_ID.indexOf(parts[2])+1;
        if(y && m>0 && d) k = keyDate(y,m,d);
      }
      if(!k) continue;
      if(!map.has(k)) map.set(k, []);
      map.get(k).push(r);
    }
    return map;
  }

  function buildMonthRows(year, month, reports){
    const onlyThisMonth = reports.filter(r=>{
      if(!r?.date) return false;
      const [y, m] = String(r.date).split('-').map(Number);
      return y === year && m === month;
    });

    const perDate   = groupReportsByDate(onlyThisMonth);
    const totalDays = daysInMonth(year, month);
    const rows = [];

    for (let d = 1; d <= totalDays; d++) {
      const k    = keyDate(year, month, d);
      const list = perDate.get(k) || [];

      if (list.length === 0) {
        rows.push({
          tanggal: tanggalLabel(year, month, d),
          teknisi: "", lokasiDari: "", lokasiKe: "", jenis: "", detail: "", status: "",
          jamMasuk: "23:55",
          jamBerangkat: "", jamTiba: "", jamMulai: "", jamSelesai: "",
          waktuPenyelesaian: 0, jarak: null, waktuTempuh: 0, keterangan: ""
        });
        continue;
      }

      list.forEach((r, idx)=>{
        const jarakVal = (r.jarakKm != null ? r.jarakKm : r.jarak);
        rows.push({
          tanggal: idx === 0 ? tanggalLabel(year, month, d) : "",
          teknisi: r.teknisi || "",
          lokasiDari: r.lokasiDari || "",
          lokasiKe: r.lokasiKe || "",
          jenis: r.jenis || "",
          detail: r.detail || "",
          status: r.status || "",
          jamMasuk: r.jamMasuk || "",
          jamBerangkat: r.jamBerangkat || "",
          jamTiba: r.jamTiba || "",
          jamMulai: r.jamMulai || "",
          jamSelesai: r.jamSelesai || "",
          waktuPenyelesaian: hmToExcelTime(r.durasiPenyelesaianStr || r.waktuPenyelesaian || ""),
          jarak: (jarakVal === "" || jarakVal == null) ? null : Number(jarakVal || 0),
          waktuTempuh: hmToExcelTime(r.waktuTempuhStr || r.waktuTempuh || ""),
          keterangan: r.keterangan || ""
        });
      });
    }
    return rows;
  }

  // ===== Export XLSX (FULL CALENDAR)
  const minutesToExcelTime = (mins)=> (mins||0)/(24*60);

  async function exportXLSX(){
    try{
      const rowsAll = loadReports().filter(r=>r.month===month);
      if(!rowsAll.length){ showToast('Data kosong untuk bulan ini.'); return; }
      if(!window.ExcelJS) { showToast('ExcelJS belum termuat.'); return; }

      // Ambil nama teknisi dari data bulan ini (per-individu)
      const uniqTek = [...new Set(rowsAll.map(r => (r.teknisi||"").trim()).filter(Boolean))];
      if (uniqTek.length === 0) { showToast('Nama teknisi tidak ditemukan di data.'); return; }
      if (uniqTek.length > 1)   { showToast('Ditemukan >1 nama teknisi. Rapikan/filter dulu sebelum export.'); return; }
      const teknisiPembuat = uniqTek[0];

      const [yyStr, mmStr] = String(month||"").split("-");
      const yy=Number(yyStr||new Date().getFullYear());
      const mm=Number(mmStr||new Date().getMonth()+1);
      const monthName=new Date(yy,mm-1,1).toLocaleDateString('id-ID',{month:'long'});
      const title=`ABSENSI TEKNISI BULAN ${monthName.toUpperCase()} ${yy}`;
      const fileName=`SPJ ${monthName} ${yy} - ${teknisiPembuat}.xlsx`;

      const dataRows = buildMonthRows(yy, mm, rowsAll);

      const wb=new ExcelJS.Workbook();
      const ws=wb.addWorksheet('Format SPJ');
      ws.properties.defaultRowHeight = 18;

      // Title
      ws.mergeCells('A1:P1');
      const cTitle=ws.getCell('A1'); cTitle.value=title; cTitle.alignment={horizontal:'center',vertical:'middle'}; cTitle.font={bold:true,size:18};

      // Header 2 baris
      ws.mergeCells('A3','A4'); ws.getCell('A3').value='Tanggal';
      ws.mergeCells('B3','B4'); ws.getCell('B3').value='Teknisi';
      ws.mergeCells('C3','D3'); ws.getCell('C3').value='Lokasi'; ws.getCell('C4').value='Dari'; ws.getCell('D4').value='Ke';
      ws.mergeCells('E3','E4'); ws.getCell('E3').value='Jenis Pekerjaan';
      ws.mergeCells('F3','F4'); ws.getCell('F3').value='Detail Pekerjaan';
      ws.mergeCells('G3','G4'); ws.getCell('G3').value='Status Pekerjaan';
      ws.mergeCells('H3','L3'); ws.getCell('H3').value='Waktu';
      ws.getCell('H4').value='Jam Masuk Laporan'; ws.getCell('I4').value='Jam Berangkat'; ws.getCell('J4').value='Jam Tiba'; ws.getCell('K4').value='Jam Mulai Pekerjaan'; ws.getCell('L4').value='Jam Selesai';
      ws.mergeCells('M3','M4'); ws.getCell('M3').value='Waktu Penyelesaian';
      ws.mergeCells('N3','N4'); ws.getCell('N3').value='Jarak Tempuh';
      ws.mergeCells('O3','O4'); ws.getCell('O3').value='Waktu Tempuh';
      ws.mergeCells('P3','P4'); ws.getCell('P3').value='Keterangan';

      // Header style
      for (const r of [3,4]){
        const row=ws.getRow(r);
        for(let c=1;c<=16;c++){
          const cell=row.getCell(c);
          cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FFC5D9F1'}};
          cell.font={bold:true};
          cell.alignment={vertical:'middle',horizontal:'center',wrapText:[5,6,16].includes(c)};
          cell.border={top:{style:'thin'},left:{style:'thin'},bottom:{style:'thin'},right:{style:'thin'}};
        }
        row.commit&&row.commit();
      }

      // ===== Data rows (FULL CALENDAR) =====
      const startRow = 5; let rIdx = startRow;

      dataRows.forEach(dr => {
        const row = ws.getRow(rIdx++);
        row.values = [
          dr.tanggal,
          dr.teknisi,
          dr.lokasiDari,
          dr.lokasiKe,
          dr.jenis,
          dr.detail,
          dr.status,
          dr.jamMasuk ? hmToExcelTime(dr.jamMasuk) : null,
          dr.jamBerangkat ? hmToExcelTime(dr.jamBerangkat) : null,
          dr.jamTiba ? hmToExcelTime(dr.jamTiba) : null,
          dr.jamMulai ? hmToExcelTime(dr.jamMulai) : null,
          dr.jamSelesai ? hmToExcelTime(dr.jamSelesai) : null,
          dr.waktuPenyelesaian,
          dr.jarak,
          dr.waktuTempuh,
          dr.keterangan
        ];

        ['H','I','J','K','L'].forEach(col => { ws.getCell(col + row.number).numFmt = 'h:mm'; });
        ['M','O'].forEach(col => { ws.getCell(col + row.number).numFmt = '[h]:mm'; });

        for (let c = 1; c <= 16; c++) {
          const cell = row.getCell(c);
          cell.alignment = { vertical: 'middle', horizontal: (c===2?'left':'center'), wrapText: [5,6,16].includes(c) };
          cell.border = { top:{style:'thin'}, left:{style:'thin'}, bottom:{style:'thin'}, right:{style:'thin'} };
        }
        row.height = 18; row.commit && row.commit();
      });

      // ===== TOTAL row (A..P) =====
      const endRow = rIdx - 1;
      const totalRowIdx = rIdx;

      ws.mergeCells(`A${totalRowIdx}:L${totalRowIdx}`);
      const totalCell = ws.getCell(`A${totalRowIdx}`);
      totalCell.value = 'TOTAL';
      totalCell.font = { bold: true };
      totalCell.alignment = { vertical:'middle', horizontal:'center' };

      ws.getCell(`M${totalRowIdx}`).value = { formula:`SUM(M${startRow}:M${endRow})` };
      ws.getCell(`N${totalRowIdx}`).value = { formula:`SUM(N${startRow}:N${endRow})` };
      ws.getCell(`O${totalRowIdx}`).value = { formula:`SUM(O${startRow}:O${endRow})` };

      ws.getCell(`M${totalRowIdx}`).numFmt = '[h]:mm';
      ws.getCell(`O${totalRowIdx}`).numFmt = '[h]:mm';

      const totalRow = ws.getRow(totalRowIdx);
      for (let c=1; c<=16; c++){
        const cell = totalRow.getCell(c);
        cell.font = { bold:true };
        cell.alignment = { vertical:'middle', horizontal: c===2 ? 'left' : 'center' };
        cell.fill = { type:'pattern', pattern:'solid', fgColor:{ argb:'FFC5D9F1' } };
        cell.border = { top:{style:'thin'}, left:{style:'thin'}, bottom:{style:'thin'}, right:{style:'thin'} };
      }
      totalRow.height = 18; totalRow.commit && totalRow.commit();

      if (wb.calcProperties) wb.calcProperties.fullCalcOnLoad = true;

      // ===== Footer tanda tangan =====
      const sigTop = totalRowIdx + 2;

      ws.getCell(`N${sigTop}`).value = `Jakarta, ${new Date().toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'})}`;
      ws.getCell(`N${sigTop}`).alignment = { horizontal: 'center', vertical: 'middle' };
      ws.getCell(`N${sigTop}`).font = { bold: true };
      ws.getCell(`N${sigTop+1}`).value = "Dibuat oleh,"; ws.getCell(`N${sigTop+1}`).font = { bold: true }; ws.getCell(`N${sigTop+1}`).alignment = { horizontal: 'center', vertical: 'middle' };

      ws.getCell(`N${sigTop+5}`).value = teknisiPembuat;
      ws.getCell(`N${sigTop+5}`).font  = { bold: true, underline: true };
      ws.getCell(`N${sigTop+5}`).alignment = { horizontal: 'center', vertical: 'middle' };
      ws.getCell(`N${sigTop+6}`).value = "Teknisi";
      ws.getCell(`N${sigTop+6}`).font  = { bold: true };
      ws.getCell(`N${sigTop+6}`).alignment = { horizontal: 'center', vertical: 'middle' };

      ws.getCell(`D${sigTop}`).value = "Mengetahui,"; ws.getCell(`D${sigTop}`).font = { bold: true }; ws.getCell(`D${sigTop}`).alignment = { horizontal: 'center', vertical: 'middle' };

      ws.getCell(`C${sigTop+5}`).value = "Yonathan Christian";
      ws.getCell(`C${sigTop+5}`).font  = { bold: true, underline: true };
      ws.getCell(`C${sigTop+5}`).alignment = { horizontal: 'center', vertical: 'middle' };
      ws.getCell(`C${sigTop+6}`).value = "Assistant Vice President"; ws.getCell(`C${sigTop+6}`).font  = { bold: true }; ws.getCell(`C${sigTop+6}`).alignment = { horizontal: 'center', vertical: 'middle' };

      ws.getCell(`E${sigTop+5}`).value = "Fitrah Rahmanto";
      ws.getCell(`E${sigTop+5}`).font  = { bold: true, underline: true };
      ws.getCell(`E${sigTop+5}`).alignment = { horizontal: 'center', vertical: 'middle' };
      ws.getCell(`E${sigTop+6}`).value = "Project Controller"; ws.getCell(`E${sigTop+6}`).font  = { bold: true }; ws.getCell(`E${sigTop+6}`).alignment = { horizontal: 'center', vertical: 'middle' };

      for(let r=sigTop+2; r<=sigTop+4; r++){ ws.getRow(r).height = 18; }

      // === smart widths ===
      function applySmartWidths(ws, {
        wrapCols = [5,6,16],
        min = 8, max = 48, padding = 2,
        minAtoP = [22,28,18,28,22,24,16,10,10,10,12,10,10,9,10,30],
        timeCols = [8,9,10,11,12],   // H..L
        durationCols = [13,15],      // M & O
        distanceCol = 14,            // N
        timeMinWidth = 11,
        durationMinWidth = 10,
        distMinWidth = 9
      } = {}) {
        autoFitColumns(ws, { min, max, padding, wrapCols });
        minAtoP.forEach((w, i) => { const col = ws.getColumn(i + 1); col.width = Math.max(col.width || 0, w); });
        const maxTimeW = Math.max(timeMinWidth, ...timeCols.map(i => ws.getColumn(i).width || 0)); timeCols.forEach(i => ws.getColumn(i).width = maxTimeW);
        const maxDurW = Math.max(durationMinWidth, ...durationCols.map(i => ws.getColumn(i).width || 0)); durationCols.forEach(i => ws.getColumn(i).width = maxDurW);
        ws.getColumn(distanceCol).width = Math.max(distMinWidth, ws.getColumn(distanceCol).width || 0);
      }
      applySmartWidths(ws);

      // Export buffer
      const buf = await wb.xlsx.writeBuffer();
      const blob=new Blob([buf],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
      const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=fileName; a.click(); URL.revokeObjectURL(url);

    }catch(err){ console.error('Export XLSX error:',err); showToast('Gagal export XLSX. Cek console.'); }
  }

   // ===== Reset bulan (BERSIHKAN LEGACY JUGA) =====
  function resetMonth(){
    const all = loadReports();
    const n = all.filter(r=>r.month===month).length;
    if(!n) return showToast('Tidak ada data untuk direset.');
    if(!confirm(`Hapus ${n} entri untuk bulan ${month}?`)) return;

    // Simpan STORAGE_KEY tersaring
    saveReports(all.filter(r=>r.month!==month));

    // Hapus legacy key (monthlyData) sekalian agar Form tidak melihat data lama lagi
    try {
      const legacyArr = LS.readJSON(LEGACY_KEY, []);
      if (legacyArr.length) {
        const keptLegacy = legacyArr.filter(r => r.month !== month);
        if (keptLegacy.length) LS.writeJSON(LEGACY_KEY, keptLegacy);
        else LS.removeItem(LEGACY_KEY);
      } else {
        LS.removeItem(LEGACY_KEY);
      }
    } catch {}

    showToast('Data bulan ini sudah dihapus.');
    applyFilters();
    pushMirrorSilent();
    try { localStorage.setItem('__monthly_broadcast', String(Date.now())); } catch {}
  }

  // ===== events
  $("q")?.addEventListener('input', applyFilters);
  $("btnExportXlsx")?.addEventListener('click', exportXLSX);
  $("btnReset")?.addEventListener('click', resetMonth);

  document.addEventListener('DOMContentLoaded', async () => {
    applyFilters?.();

    // Pull → merge → render
    const doPull = async () => {
      if (window.MonthlySync?.pull) {
        await window.MonthlySync.pull(monthlyGetLocal, monthlySetLocal, () => applyFilters());
        return;
      }
      try {
        const ok = await (window.DriveSync?.tryResume?.() || Promise.resolve(false));
        if (!ok && !window.DriveSync?.isLogged?.()) return;
        const cloudObj = await window.DriveSync?.getJson?.(monthlyCloudFile());
        const incoming =
            Array.isArray(cloudObj?.data) ? cloudObj.data
          : Array.isArray(cloudObj)       ? cloudObj
          : [];
          await monthlySetLocal(incoming); // REPLACE lokal dengan cloud
          applyFilters?.();
        
      } catch (e) {
        console.warn('[Monthly] pull gagal:', e);
      }
    };
    await doPull();
  });

  // Jika tab lain mengubah storage -> refresh tabel
  window.addEventListener('storage', (e) => {
    if (!e?.key) return;
    const k = e.key.endsWith('::'+getUidOrAnon()) ? e.key.split('::')[0] : e.key;
    if (k === STORAGE_KEY || k === LEGACY_KEY) applyFilters();
  });

  // ===== merge helper (dipakai di pull & migrasi)
  function mergeByIdNewest(localArr, incomingArr){
    const map = new Map();
    (Array.isArray(localArr)?localArr:[]).forEach(r => {
      const id = r.id || [r.month,r.date,r.teknisi,r.createdAt].filter(Boolean).join('|');
      map.set(id, r);
    });
    (Array.isArray(incomingArr)?incomingArr:[]).forEach(r => {
      const id = r.id || [r.month,r.date,r.teknisi,r.createdAt].filter(Boolean).join('|');
      const ex = map.get(id);
      const tNew = new Date(r.updatedAt || r.createdAt || 0).getTime();
      const tOld = new Date(ex?.updatedAt || ex?.createdAt || 0).getTime();
      if (!ex || tNew >= tOld) map.set(id, r);
    });
    return Array.from(map.values());
  }
})();
